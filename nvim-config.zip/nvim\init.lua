-- 1. BASIC SETTINGS
vim.o.termguicolors = true  -- Enable true color support
vim.o.background = "dark"   -- Set background to dark or light
vim.o.number = true         -- Show line numbers
vim.o.relativenumber = true -- Show relative line numbers
vim.o.tabstop = 4         -- Set tab width to 4 spaces
vim.o.shiftwidth = 4      -- Set shift width to 4 spaces
vim.o.expandtab = true      -- Use spaces instead of tabs
vim.o.smartindent = true    -- Enable smart indent

-- 2. ENSURE VIM-PLUG IS INSTALLED
local plug_path = vim.fn.stdpath("data") .. "/site/autoload/plug.vim"
if not vim.loop.fs_stat(plug_path) then
  vim.fn.system({
    "curl", "-fLo", plug_path,
    "--create-dirs", "https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim"
  })
end

-- 3. LOAD PLUGINS USING VIM-PLUG
vim.cmd [[
call plug#begin('~/.local/share/nvim/plugged')

Plug 'nvim-tree/nvim-tree.lua'
Plug 'catppuccin/nvim', { 'as': 'catppuccin' }
Plug 'nvim-telescope/telescope.nvim', { 'tag': '0.1.5' }
Plug 'nvim-lua/plenary.nvim'

call plug#end()
]]

-- 4. INSTALL PLUGINS IF NOT INSTALLED
vim.cmd("autocmd VimEnter * PlugInstall --sync | source $MYVIMRC")

-- 5. LOAD CONFIGURATION FOR PLUGINS

-- nvim-tree
local status_ok, nvim_tree = pcall(require, "nvim-tree")
if status_ok then
  nvim_tree.setup({
    view = {
      width = 30,
      side = "left",
    },
    renderer = {
      highlight_git = true,
      icons = {
        show = { git = true },
      },
    },
    actions = {
      open_file = { quit_on_open = true },
    },
  })
  -- Keybinding
  vim.keymap.set('n', '<leader>e', ':NvimTreeToggle<CR>', { noremap = true, silent = true })
else
  print("nvim-tree is not installed")
end

-- telescope
local status_telescope, telescope = pcall(require, 'telescope')
if status_telescope then
  telescope.setup({
    defaults = {
      file_ignore_patterns = { "node_modules", ".git" },
      mappings = {
        i = {
          ["<C-u>"] = false, -- Clear input
          ["<C-d>"] = false, -- Scroll down
        },
      },
    },
  })
  local builtin = require('telescope.builtin')
  vim.keymap.set('n', '<leader>ff', builtin.find_files, {})
  vim.keymap.set('n', '<leader>fg', builtin.live_grep, {})
  vim.keymap.set('n', '<leader>fb', builtin.buffers, {})
  vim.keymap.set('n', '<leader>fh', builtin.help_tags, {})
else
  print("Telescope is not installed")
end

-- 6. COLORS AND THEME
local status_catppuccin, catppuccin = pcall(require, "catppuccin")
if status_catppuccin then
  catppuccin.setup({
    flavour = "mocha",
    transparent_background = false,
    integrations = {
      telescope = true,
      nvimtree = true,
    },
  })
  vim.cmd("colorscheme catppuccin-mocha")
else
  print("Catppuccin theme is not installed")
end

